import os

# ======================= User Parameters =======================
N_POLM = 50                  # number of repeat units of the first block (POLM)
N_POLD = 50                  # number of repeat units of the second block (POLD); use 50 or 100
protonation_levels = list(range(0, 101, 10))  # 0, 10, ..., 100 (%)
output_dir = "itps_nb"
VERBOSE_TEST_PRINTS = True   # print per-step diagnostics
SEED_REMAINDER = 9           
os.makedirs(output_dir, exist_ok=True)
# ===============================================================

# ---------------------- Sanity Checks --------------------------
assert N_POLD % 10 == 0, "This uniform scheme assumes N_POLD is a multiple of 10."
# ---------------------------------------------------------------

# ==================== Force-Field Parameters ===================
bond_params = {
    ("CM", "OM"): (1, 0.0, 0),
    ("CM", "CM"): (1, 0.0, 0),
    ("OM", "NC"): (1, 0.0, 0),
    ("OM", "NH"): (1, 0.0, 0),
}

atom_order_names = ["CM", "OM", "NC", "NH"]

def add_bond(lines, i, j, at_i, at_j):
    """Append a GROMACS bond line using canonicalized (type-ordered) key."""
    key = tuple(sorted((at_i, at_j), key=lambda x: atom_order_names.index(x)))
    func, r0, kb = bond_params[key]
    lines.append(f"{i:5d} {j:5d} {func:5d} {r0:12.3f} {kb:12.0f}")

# ===============================================================

# ================= ASCII visualization helpers =================
def ascii_map(N, selected, proton_char="P", deprot_char="D"):
    """Return a single-line string of length N with P/D characters."""
    sel = set(selected)
    chars = [proton_char if i in sel else deprot_char for i in range(N)]
    return "".join(chars)

def ascii_ticks(N):
    """Return (tick_line, label_line) for positions 0,10,20,..."""
    tick_line  = "".join("|" if i % 10 == 0 else " " for i in range(N))
    label_line = "".join(str((i // 10) % 10) if i % 10 == 0 else " " for i in range(N))
    return tick_line, label_line
# ===============================================================

# ============== Uniform modulo-10 selection (nested) ==========
def circular_farthest_order(M, seed=0, alternate_ties=True):
    """
    Order residues {0..M-1} on a circle by farthest-first (max-min circular distance).
    The prefix of length k gives k residues that are as evenly spaced as possible.
    """
    assert 1 <= M
    selected = [seed % M]
    remaining = set(range(M)) - {selected[0]}
    choose_low = True
    def cdist(a, b):  # circular distance on M nodes
        d = abs(a - b)
        return min(d, M - d)
    while remaining:
        best_d = -1
        cands = []
        for r in remaining:
            d = min(cdist(r, s) for s in selected)
            if d > best_d:
                best_d = d
                cands = [r]
            elif d == best_d:
                cands.append(r)
        # tie-break to keep things balanced
        r = (min(cands) if choose_low else max(cands)) if alternate_ties else min(cands)
        choose_low = not choose_low
        selected.append(r)
        remaining.remove(r)
    return selected  # list of residues 0..M-1

# Build remainder order for modulo-10 buckets; first remainder is SEED_REMAINDER (e.g., 9)
remainder_order = circular_farthest_order(10, seed=SEED_REMAINDER, alternate_ties=True)

def build_uniform_nested_sets(N, levels, remainder_order):
    """
    For N divisible by 10, at step k (k=0..10) select the first k remainders r in remainder_order,
    and protonate all indices i where (i % 10) ∈ {r_1,..,r_k}. This yields strictly nested, periodic,
    and visually uniform distributions (your desired pattern).
    """
    result = {}
    for pct in sorted(levels):
        k = pct // 10  # number of remainder classes to include (0..10)
        chosen_remainders = set(remainder_order[:k])
        selected = [i for i in range(N) if (i % 10) in chosen_remainders]
        result[pct] = selected
    return result
# ===================================================================

# =================== Diagnostics / Metrics =========================
def selection_metrics_linear(N, indices):
    """
    Diagnostics on a linear chain (not circular).
    Returns a dict with counts and spacing statistics.
    """
    S = set(indices)
    sorted_idx = sorted(S)
    n = len(sorted_idx)

    # gaps on a linear chain (consecutive differences)
    if n >= 2:
        diffs = [b - a for a, b in zip(sorted_idx[:-1], sorted_idx[1:])]
        min_gap = min(diffs)
        max_gap = max(diffs)
        mean_gap = sum(diffs) / len(diffs)
    else:
        min_gap = max_gap = mean_gap = None

    return {
        "n": n,
        "min_gap": min_gap,
        "max_gap": max_gap,
        "mean_gap": mean_gap,
    }
# ===================================================================

# ===================== Precompute Selections =======================
uniform_sets = build_uniform_nested_sets(N_POLD, protonation_levels, remainder_order)
# ===================================================================

# =================== Write ITPs + Diagnostics ======================
for pct in protonation_levels:
    N_TOTAL = N_POLM + N_POLD
    n_prot = int(round(N_POLD * pct / 100))
    prot_indices = set(uniform_sets[pct])  # indices 0..N_POLD-1 inside the POLD block

    # --- diagnostics print ---
    if VERBOSE_TEST_PRINTS:
        m = selection_metrics_linear(N_POLD, prot_indices)
        print(
            f"[{pct:3d}%] n={m['n']:3d}; "
            f"gaps(min/mean/max)={m['min_gap']}/{m['mean_gap']}/{m['max_gap']}; "
            f"remainder order (prefix {pct//10}): {remainder_order[:pct//10]}"
        )
        # ASCII visualization for POLD only
        bar = ascii_map(N_POLD, prot_indices)    # 'P'/'D' string of length N_POLD
        ticks, labels = ascii_ticks(N_POLD)
        print("   map :", bar)
        print("   tick:", ticks)
        print("   dec :", labels)

        # safety: count matches target
        assert m["n"] == n_prot, f"Count mismatch at {pct}%: got {m['n']} vs expected {n_prot}"

    # --- build atom list (3 atoms per monomer as in your representation) ---
    atoms = []
    for m_idx in range(N_TOTAL):
        resnr = m_idx + 1
        if m_idx < N_POLM:
            residu = "PM"
            side_atoms = [("SCM", "CM"), ("N4M", "OM"), ("SQ2", "NC")]
        else:
            residu = "PD"
            rel = m_idx - N_POLM  # 0..N_POLD-1
            if rel in prot_indices:
                side_atoms = [("SCM", "CM"), ("N4M", "OM"), ("SQ2p", "NH")]
            else:
                side_atoms = [("SCM", "CM"), ("N4M", "OM"), ("N3a", "NH")]
        for atype, aname in side_atoms:
            atoms.append((atype, resnr, residu, aname))

    # --- write ITP content ---
    lines = []
    lines.append("[ moleculetype ]")
    lines.append("; name  nrexcl")
    lines.append("POL    1\n")

    # atoms
    lines.append("[ atoms ]")
    lines.append(";   nr    type   resnr  residu    atom    cgnr  charge")
    charge = {"SCM": 0.0, "N4M": 0.0, "SQ2": 1.0, "SQ2p": 1.0, "N3a": 0.0}
    for idx, (atype, resnr, residu, aname) in enumerate(atoms, start=1):
        lines.append(f"{idx:6d} {atype:>7s} {resnr:7d} {residu:>7s} {aname:>7s} {idx:7d} {charge[atype]:7.3f}")

    # bonds
    bond_lines = []
    for m_idx in range(N_TOTAL):
        cm = 3*m_idx + 1
        om = 3*m_idx + 2
        xh = 3*m_idx + 3
        add_bond(bond_lines, cm, om, "CM", "OM")
        atom_x = "NC" if m_idx < N_POLM else "NH"
        add_bond(bond_lines, om, xh, "OM", atom_x)
        if m_idx < N_TOTAL - 1:
            add_bond(bond_lines, cm, 3*(m_idx+1) + 1, "CM", "CM")
    lines.append("\n[ bonds ]\n;  ai    aj funct           c0           c1")
    lines.extend(bond_lines)

    # write file
    fname = os.path.join(output_dir, f"POLD_{pct}pct.itp")
    with open(fname, 'w') as f:
        f.write("\n".join(lines))
        f.write("\n\n[ position_restraints ]\n")
        f.write(";     i funct       fcx        fcy        fcz\n")
        f.write("      1 1 1000 1000 1000\n")
    print(f"Written {fname} with {n_prot}/{N_POLD} protonated monomers\n")
# ===================================================================
