
for it in {5..100..5}; do
    echo "=== Processing ${it}% ==="
    mkdir -p "${it}"
    cp -r files/MD files/itp files/gmx.top files/POL.itp files/convert.py files/write_itp_gro.py "${it}/"
    cp -r files/params.in "${it}/"

    sed -i "66s|.*|target_pct           = ${it}|" ${it}/params.in
done

cd 5
gmx grompp -f ../run.mdp -o run.tpr -c ../md.gro -r ../md.gro -p ../gmx_ini.top -maxwarn 10
gmx genion -s run.tpr -o 0.gro -nname CL -neutral <<EOF
6
EOF
W_run1=141222
CL_run1=3201
sed -i "19s|.*|W               ${W_run1}|"  ../gmx_ini.top
sed -i "20s|.*|CL              ${CL_run1}|" ../gmx_ini.top

gmx grompp -f ../run.mdp -o 0.tpr -c 0.gro -r 0.gro -p ../gmx_ini.top -maxwarn 10
cd ..


cd 100
cd MD
sed -i "6s|.*|nsteps                   = 100000000|" run.mdp
cd ..
cd ..


