
source /home/miniconda3/etc/profile.d/conda.sh
conda activate openmm

########################################################################

for percent in 10 20 30 40 50 60 70 80 90 100; do
  echo "=== Processing ${percent}% ==="
  prev=$((percent - 10))  

  cd "${percent}"
  gmx grompp -f ../run.mdp \
             -o run.tpr \
             -c ../${prev}/3/md.gro \
             -r ../${prev}/3/md.gro \
             -p run.top \
             -maxwarn 10

  gmx genion  -s run.tpr \
              -o pro.gro \
              -nname CL \
              -neutral <<EOF
5
EOF

  gmx make_ndx -f pro.gro \
               -o index.ndx <<EOF
!2
q
EOF

  # openmm mmc
  python run.py


  for stage in 1 2 3; do
    echo "-- Stage ${stage} for ${percent}% --"
    cd "${stage}"

    if [[ "${stage}" -eq 1 ]]; then
      START=../best.gro
    else
      prev_stage=$((stage-1))
      START=../${prev_stage}/md.gro
    fi

    REF=../best.gro

    gmx grompp  -f run.mdp \
                -o run.tpr \
                -c "${START}" \
                -r "${REF}" \
                -p ../run1.top \
                -n ../index.ndx \
                -maxwarn 10

    gmx mdrun -deffnm md \
              -s run.tpr \
              -v \
              -ntmpi 1  \
              -ntomp 12 \
              -nb gpu

    cd ..
  done

  cd ..
done
  
conda deactivate