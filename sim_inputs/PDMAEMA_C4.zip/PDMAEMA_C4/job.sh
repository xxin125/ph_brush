

export GMX_MAXCONSTRWARN=-1
export OMP_NUM_THREADS=4

set -euo pipefail
IFS=$'\n\t'

bash cp.sh

GMX_CMD="gmx"          
N_THREADS_OMP=4
N_MPI=6

for it in {5..100..5}; do
    it_dir="${it}"
    echo "=== Processing ${it_dir} ==="

    if [[ ! -d "${it_dir}" ]]; then
        echo "Directory ${it_dir} not found, skipping."
        continue
    fi

    pushd "${it_dir}" >/dev/null

    prev_it=$((it - 5))

    if [[ -f "${prev_it}.tpr" && -f "${prev_it}.gro" ]]; then
        echo "[convert] ${prev_it}.tpr + ${prev_it}.gro -> MC_input.data"
        python convert.py ${prev_it}.tpr ${prev_it}.gro MC_input.data --typemap ../types.json
    else
        echo "WARNING: ${prev_it}.tpr or ${prev_it}.gro not found. Skipping MC for ${it}."
    fi

    if [[ -f "MC_input.data" ]]; then
        echo "[MCMD it]  = ${it}"
        
        MC MC_input.data params.in 

        echo "[post] write_itp_gro from phase2.data -> best.gro"
        python write_itp_gro.py \
            --in-data phase2.data \
            --out-data-sorted phase2_sorted.data \
            --out-itp-dir itp \
            --n-polm 0 \
            --exclude-types 1,6,7,8 \
            --pro-threshold 0.5 \
            --gro-in ${prev_it}.gro \
            --gro-out best.gro \
            --w-type 7 --cl-type 8 \
            --update-top gmx.top \
            --species-W-name W \
            --species-CL-name CL
    fi

    if [[ ! -f best.gro ]]; then
        echo "ERROR: best.gro not found in ${it_dir}, cannot run make_ndx. Skipping this it."
        popd >/dev/null
        continue
    fi

    echo "[step] creating index.ndx from best.gro"
    ${GMX_CMD} make_ndx -f best.gro -o index.ndx <<'EOF'
!2
q
EOF

    stage_dir="MD"
    if [[ ! -d "${stage_dir}" ]]; then
        echo "Stage dir ${stage_dir} not found; skipping MD."
        popd >/dev/null
        continue
    fi
    pushd "${stage_dir}" >/dev/null

    START="../best.gro"
    REF="../best.gro"

    if [[ ! -f "${START}" ]]; then
        echo "Start file ${START} not found; skipping this MD."
        popd >/dev/null
        popd >/dev/null
        continue
    fi

    echo "[grompp] creating run.tpr (start=${START}, ref=${REF})"
    ${GMX_CMD} grompp -f run.mdp -o run.tpr -c "${START}" -r "${REF}" -p ../gmx.top -n ../index.ndx -maxwarn 10

    echo "[mdrun] running MD"
    ${GMX_CMD} mdrun -deffnm md -s run.tpr -v -ntmpi ${N_MPI} -ntomp ${N_THREADS_OMP} -nb gpu -update gpu -bonded gpu -pme gpu -npme 1 -dlb auto -dd 5 1 1

    popd >/dev/null

    next=$((10#${it} + 5))
    next_dir="../${next}"
    echo "next=${next}; target dir=${next_dir}"

    if [[ -d "${next_dir}" ]]; then
        if [[ -f "MD/md.gro" ]]; then
            echo "Copying MD/md.gro -> ${next_dir}/${it}.gro"
            cp -v "MD/md.gro" "${next_dir}/${it}.gro"
        else
            echo "Warning: MD/md.gro not found; skipping copy to ${next_dir}"
        fi

        if [[ -f "MD/run.tpr" ]]; then
            echo "Copying MD/run.tpr -> ${next_dir}/${it}.tpr"
            cp -v "MD/run.tpr" "${next_dir}/${it}.tpr"
        else
            echo "Warning: MD/run.tpr not found; skipping copy to ${next_dir}"
        fi
    else
        echo "Next dir ${next_dir} not found; skipping copy"
    fi

    popd >/dev/null
done

echo "All done."