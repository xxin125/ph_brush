
import math
import numpy as np
from sys import stdout

from openmm.app import GromacsGroFile, GromacsTopFile, Simulation, PME
from openmm import (VerletIntegrator, NonbondedForce, Platform,
                    CustomExternalForce, CustomCVForce, CustomNonbondedForce)
from openmm.unit import (
    nanometer,
    kilojoule_per_mole,
    elementary_charge,
    picosecond,
)

# ---------------------------------------------------------------------------- #

gro_file       = "pro.gro"
top_file       = "run2.top"
gmx_topdir     = "."
ion_name       = "CL"

slab_scale_f   = 3.0     
epsilon_r      = 15.0    
cutoff_nm      = 1.1 

beta           = 1.0 / (0.008314462 * 300.0)  # 1/(k_B T)
rng_seed       = 2025       
n_steps        = 1_000_000    
patience       = 500        

# ---------------------------------------------------------------------------- #

gro = GromacsGroFile(gro_file)
box_vectors = list(gro.getPeriodicBoxVectors())
box_vectors[2] = box_vectors[2] * slab_scale_f

top = GromacsTopFile(
    top_file,
    periodicBoxVectors=box_vectors,
    includeDir=gmx_topdir,
)

# ---------------------------------------------------------------------------- #

system = top.createSystem(
    nonbondedMethod=PME,
    nonbondedCutoff=cutoff_nm * nanometer,
    constraints=None,
)

# ---------------------------------------------------------------------------- #

nb = next(f for f in system.getForces() if isinstance(f, NonbondedForce))
print("NB Method =", nb.getNonbondedMethod())       
print("NB DispCorr (before) =", nb.getUseDispersionCorrection())
print("NB Switching (before) =", nb.getUseSwitchingFunction())
print("Cutoff (nm) =", nb.getCutoffDistance().value_in_unit(nanometer))

nb.setUseDispersionCorrection(False)
nb.setUseSwitchingFunction(False)

lj_custom = None
for f in system.getForces():
    if isinstance(f, CustomNonbondedForce) and f.getName() == "LennardJonesForce":
        lj_custom = f
        break

if lj_custom is not None:
    print("Custom LJ LRC (before) =", lj_custom.getUseLongRangeCorrection())
    lj_custom.setUseLongRangeCorrection(False)           
    print("Custom LJ LRC (after) =", lj_custom.getUseLongRangeCorrection())
else:
    print("No Custom LJ force (no nonbond_params detected).")

print("NB DispCorr (after)  =", nb.getUseDispersionCorrection())
print("NB Switching (after) =", nb.getUseSwitchingFunction())

# ---------------------------------------------------------------------------- #

if abs(epsilon_r - 1.0) > 1e-8:
    scale = 1.0 / math.sqrt(epsilon_r)
    for f in system.getForces():
        if isinstance(f, NonbondedForce):
            nb_force = f
            break
    for i in range(nb_force.getNumParticles()):
        q, sig, eps = nb_force.getParticleParameters(i)
        nb_force.setParticleParameters(i, q * scale, sig, eps)
    for i in range(nb_force.getNumExceptions()):
        p1, p2, qq, sig, eps = nb_force.getExceptionParameters(i)
        nb_force.setExceptionParameters(i, p1, p2, qq * scale * scale, sig, eps)
else:
    for f in system.getForces():
        if isinstance(f, NonbondedForce):
            nb_force = f
            break

# ---------------------------------------------------------------------------- #

charges_e = [nb_force.getParticleParameters(i)[0].value_in_unit(elementary_charge)
             for i in range(nb_force.getNumParticles())]

k_e = 138.935456 * kilojoule_per_mole * nanometer / elementary_charge**2

a, b, c = box_vectors
V = np.dot(a.value_in_unit(nanometer),
           np.cross(b.value_in_unit(nanometer),
                    c.value_in_unit(nanometer))) * nanometer**3

scale_f = (2 * math.pi * k_e / V).value_in_unit(
            kilojoule_per_mole / (elementary_charge**2 * nanometer**2))

# q·z：Σ q_i z_i
zq = CustomExternalForce("q * z") 
zq.addPerParticleParameter("q")
for idx, q_i in enumerate(charges_e):
    zq.addParticle(idx, [q_i])

# U_corr = scale·Mz²
slab = CustomCVForce("scale * mz^2")
slab.addGlobalParameter("scale", scale_f)
slab.addCollectiveVariable("mz", zq)   
system.addForce(slab)   

# ---------------------------------------------------------------------------- #

integrator = VerletIntegrator(0.001 * picosecond)
platform   = Platform.getPlatformByName("CUDA")
sim        = Simulation(top.topology, system, integrator, platform=platform)

sim.context.setPositions(gro.getPositions())

# ---------------------------------------------------------------------------- #

state      = sim.context.getState(getEnergy=True, getPositions=True)
pos_array  = state.getPositions(asNumpy=True)
cur_E      = state.getPotentialEnergy().value_in_unit(kilojoule_per_mole)
best_E     = cur_E
best_xyz   = pos_array.copy()

def compute_total_energy(ctx):
    return ctx.getState(getEnergy=True).getPotentialEnergy().value_in_unit(
        kilojoule_per_mole
    )

# ---------------------------------------------------------------------------- #

ion_idx    = [atom.index for atom in top.topology.atoms() if atom.residue.name == ion_name]
wat_idx    = [atom.index for atom in top.topology.atoms() if atom.residue.name == "W"]

rng        = np.random.default_rng(rng_seed)
no_improve = 0

print("Starting MC swap ...", flush=True)
for step in range(1, n_steps + 1):

    i = int(rng.choice(ion_idx))
    w = int(rng.choice(wat_idx))

    pos_array[[i, w]] = pos_array[[w, i]]
    sim.context.setPositions(pos_array)

    new_E = compute_total_energy(sim.context)
    dE    = new_E - cur_E

    if dE < 0 or rng.random() < math.exp(-beta * dE):
        cur_E = new_E
        if new_E < best_E:
            best_E, best_xyz = new_E, pos_array.copy()
            no_improve = 0
        else:
            no_improve += 1
    else:
        pos_array[[i, w]] = pos_array[[w, i]]
        sim.context.setPositions(pos_array)
        no_improve += 1

    if step % 100 == 0:
        print(f"Step {step:7d}: E = {cur_E:10.3f}  best = {best_E:10.3f}  no_improve = {no_improve}", flush=True)

    if no_improve >= patience:
        print(f"Converged after {step} MC steps (no improvement in last {patience}).", flush=True)
        break
else:
    print("Reached max MC steps without convergence.", flush=True)

print(f"Done!  Best energy  = {best_E:.3f} kJ/mol")

# ---------------------------------------------------------------------------- #

def write_gro(filename, positions_nm, box_vecs, topology):
    N = positions_nm.shape[0]
    Lx = box_vecs[0][0].value_in_unit(nanometer)
    Ly = box_vecs[1][1].value_in_unit(nanometer)
    Lz = box_vecs[2][2].value_in_unit(nanometer) / slab_scale_f  
    with open(filename, "w") as f:
        f.write("Generated by MC swap\n")
        f.write(f"{N:5d}\n")
        for res in topology.residues():
            for atom in res.atoms():
                idx = atom.index
                x, y, z = positions_nm[idx]
                resnum   = (res.index + 1) % 100000
                atomnum  = (atom.index + 1) % 100000
                resname  = res.name[:5].ljust(5)
                atomname = atom.name[:5].rjust(5)
                f.write(f"{resnum:5d}{resname}{atomname}{atomnum:5d}{x:8.3f}{y:8.3f}{z:8.3f}\n")
        f.write(f"{Lx:10.5f}{Ly:10.5f}{Lz:10.5f}\n")

state_final = sim.context.getState(getPositions=True, enforcePeriodicBox=True)
write_gro("best.gro", best_xyz, state_final.getPeriodicBoxVectors(), top.topology)
print("Wrote best.gro")

# ---------------------------------------------------------------------------- #